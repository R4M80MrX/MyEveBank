const electron = require("electron")
const app = electron.app
const BrowserWindow = electron.BrowserWindow
const notifier = require('node-notifier')
const configuration = require('./configuration')

const path = require('path')
const url = require('url')
const ipc = electron.ipcMain;
// const ipcRenderer = require('electron').ipcRenderer

var remote = electron.remote;
var Tray = electron.Tray;
var Menu = electron.Menu;

let mainWindow
let settingsWindow

function createWindow () {
    mainWindow = new BrowserWindow({
        // useContentSize: true,
    	frame: false,
    	height: 600,
        width: 1000,
        minWidth: 1000,
        minHeight: 600,
        // transparent: true
    })
    mainWindow.loadURL(
    	url.format({pathname: path.join(__dirname,"/app/", 'main.html'),
        protocol: 'file:',
        slashes: true
    }))

    mainWindow.webContents.openDevTools()

    mainWindow.on('closed', function () {
        mainWindow = null
    })

    var tray_icon = path.join(__dirname, '/app/static/img/logo.ico')

    var trayMenuTemplate = [
        {
            label: 'Baobao Bank',
            enabled: false
        },
        {
            label: 'Settings',
        },
        {
            label: 'Quit',
            click: function () {
                app.quit();
            }
        },
    ]

    let mytray = new Tray(tray_icon)

    mytray.setToolTip("Baobao Bank V1.0.0")
    const contextMenu = Menu.buildFromTemplate(trayMenuTemplate)
    mytray.setContextMenu(contextMenu)
    mytray.on('double-click', () => {
        mainWindow.show()
        mainWindow.focus()
    })

    notifier.notify({
        title: 'Message from BBBank',
        message: '欢迎使用宝宝银行客户端',
        icon: path.join(__dirname, 'notify.png')
    });
}

ipc.on('open-settings-window', function () {
    if (settingsWindow) {
        return;
    }

    settingsWindow = new BrowserWindow({
        frame: false,
        height: 300,
        resizable: false,
        width: 450,
        alwaysOnTop: true
    });

    settingsWindow.loadURL(
        url.format({
            pathname: path.join(__dirname, "/app/", 'settings.html'),
            protocol: 'file:',
            slashes: true
        }))

    settingsWindow.on('closed', function () {
        settingsWindow = null;
    });
});

ipc.on('close-settings-window', function () {
    if (settingsWindow) {
        settingsWindow.close();
    }
});

app.on('ready', function () {
    if (!configuration.readSettings('server')) {
        configuration.saveSettings('server', ['127.0.0.1', '8311']);
    }
    createWindow();
})

app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') {
        app.quit()
    }
})

app.on('activate', function () {
    if (mainWindow === null) {
        createWindow();
    }
})



ipc.on('window-all-closed', () => {
    app.quit()
})

// 隐藏窗口
ipc.on('hide-main-window', function () {
    app.quit()
})

// 小化
ipc.on('hide-window', () => {
    mainWindow.minimize()
})
// 最大化
ipc.on('show-window', () => {
    mainWindow.maximize()
})
// 还原
ipc.on('orignal-window', () => {
    mainWindow.unmaximize()
})

ipc.on('notify', (event, arg) => {
    var data = JSON.parse(arg);
    data.icon = path.join(__dirname, 'notify.png');
    if (!mainWindow_focus)
        notifier.notify(data);
})


const ipcRenderer = require('electron').ipcRenderer;

// var closeEl = document.querySelector('#close');
// console.log(closeEl);
// closeEl.addEventListener('click', function () {
//     ipcRenderer.send('close-main-window');
// });

var isBig = true;

$(document).on('click', '.close', function () {
    console.log(1)
    ipcRenderer.send('hide-main-window')
})
// 最大化
$(document).on('click', '.max', function () {
    if (isBig) {
        ipcRenderer.send('show-window')
    } else {
        ipcRenderer.send('orignal-window')
    }
    isBig = !isBig
})
// 最小化
$(document).on('click', '.min', function () {
    ipcRenderer.send('hide-window')
})

$(document).on('click', '.settings', function () {
    ipcRenderer.send('open-settings-window')
})

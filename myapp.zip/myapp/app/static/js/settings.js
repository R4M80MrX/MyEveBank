const ipcRenderer = require('electron').ipcRenderer;
const configuration = require('../configuration.js');

$(document).on('click', '.close', function () {
    console.log(1)
    ipcRenderer.send('close-settings-window')
})

var server = configuration.readSettings('server');

var inputIP = document.getElementById('ipaddr');
var inputPort = document.getElementById('port');

console.log(inputIP);